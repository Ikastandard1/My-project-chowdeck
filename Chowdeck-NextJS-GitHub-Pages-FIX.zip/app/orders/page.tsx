import Link from 'next/link';
import type { Metadata } from 'next';
export const metadata:Metadata={title:'Orders'};
export default function Orders(){return <main className="page-main"><div className="page-title"><span className="eyebrow">YOUR FOOD JOURNEY</span><h1>Orders</h1><p>Track your recent and current orders.</p></div><div className="order-card"><div className="order-icon">🍛</div><div><span className="status">● Sample order</span><h3>Jollof Rice Special</h3><p>Demo order · Estimated arrival 25–35 min</p></div><Link href="/explore" className="text-link">Order again ↗</Link></div><div className="empty-note">This is sample order content. Live order tracking requires a backend.</div></main>}
