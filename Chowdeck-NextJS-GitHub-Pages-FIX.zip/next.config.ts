import type { NextConfig } from 'next';

// GitHub Pages only serves static files. During GitHub Actions, derive the
// repository subpath automatically so assets and links work at /REPO-NAME/.
const repositoryName = process.env.GITHUB_REPOSITORY?.split('/')[1];
const isUserOrOrgSite = repositoryName?.endsWith('.github.io') ?? false;
const basePath = process.env.GITHUB_ACTIONS === 'true' && repositoryName && !isUserOrOrgSite
  ? `/${repositoryName}`
  : '';

const nextConfig: NextConfig = {
  output: 'export',
  trailingSlash: true,
  basePath,
  poweredByHeader: false,
  images: {
    unoptimized: true,
    remotePatterns: [{ protocol: 'https', hostname: 'images.unsplash.com' }],
  },
};

export default nextConfig;
