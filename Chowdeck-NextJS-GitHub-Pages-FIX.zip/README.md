# Chowdeck-inspired Next.js storefront demonstration

This is a **new Next.js adaptation** of the earlier static HTML/CSS/JavaScript Chowdeck-inspired prototype created for portfolio demonstration. The original was not built with Next.js; this version is a separate adaptation and should be described that way.

## Stack
- Next.js App Router (15.5.4)
- React 19 + TypeScript
- Shared cart state via React Context; cart persists in localStorage
- Static product route generation for the sample catalogue
- Per-product metadata and Product JSON-LD
- Responsive styling adapted from the original prototype

## Run locally
1. Install Node.js 20.9+.
2. Run `npm install`.
3. Run `npm run dev` and open `http://localhost:3000`.
4. Run `npm run build` before deployment.

## Routes
- `/` home
- `/explore` search and category filtering
- `/product/1` through `/product/8` product detail pages
- `/cart` persistent demo cart and sample checkout action
- `/orders` sample order view
- `/profile` demo profile view

## Important limitations
- This is a portfolio demo, not a live production ordering service.
- There is no backend, real account authentication, inventory API, delivery integration or payment processing.
- The product catalogue is sample data. Product structured data is illustrative; do not launch it publicly as a real store without replacing sample details, setting a real canonical domain, and adding backend validation.
- `metadataBase` is intentionally set to `https://example.com` and should be replaced with the deployed demo domain before public release.
- Robots are configured to disallow indexing for the demo.
- The design is inspired by a food-delivery interface and is not an official Chowdeck website or affiliated with Chowdeck.


## GitHub Pages deployment

This project is configured for GitHub Pages static export. Push the contents of this folder to the repository's `main` or `master` branch. GitHub Actions will build the site and publish the generated `out` folder.

1. Open repository **Settings → Pages**.
2. Under **Build and deployment → Source**, select **GitHub Actions**.
3. Open the **Actions** tab and wait for **Deploy Next.js site to GitHub Pages** to finish successfully.
4. Open the Pages URL shown in the deployment job.

The workflow sets the repository subpath automatically. GitHub Pages supports only the static features exported at build time; it does not run a Next.js server.
